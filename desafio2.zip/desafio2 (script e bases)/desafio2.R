# Instalando e acionando pacotes ------------------------------------------------------

install.packages('tidyverse')
install.packages("viridis")
library(tidyverse)
library(magrittr) # %>% 
library(viridis)
library(gridExtra)

# Importando as bases de dados --------------------------------------------

obitos_regioes <- read_delim("ObitosRegioes.txt", 
                             delim = ";", escape_double = FALSE, trim_ws = TRUE)

obitos_cor <- read_delim("ObitosCor.txt", 
                         delim = ";", escape_double = FALSE, trim_ws = TRUE)

pop_total_regioes <- readxl::read_excel("Pop_total_Regioes.xlsx")

renda_per_capita <- readxl::read_excel("Renda per capita média.xlsx")


# Tratando as bases de dados ----------------------------------------------

# As bases de dados possuem diversas variáveis em character, enquanto o que precisamos são elas em numeric. Além disso, a base possui "-" no lugar dos zeros
obitos_regioes %>% 
  dplyr::select(c(1:6)) %>%
  dplyr::rename(ano_obito = 1,
                regiao_norte = 2,
                regiao_nordeste = 3,
                regiao_sudeste = 4,
                regiao_sul = 5,
                regiao_centro_oeste = 6) %>% 
  dplyr::filter(ano_obito != "Total") %>% 
  dplyr::mutate_if(is.character, as.numeric) %>% 
  dplyr::mutate_if(is.numeric, function(x){ifelse(is.na(x), 0, x)}) -> obitos_regioes

obitos_cor %>% 
  dplyr::rename(ano_obito = 1,
                branca = 2,
                preta = 3,
                parda = 4,
                indigena = 5,
                total = 6) %>% 
  dplyr::filter(ano_obito != "Total") %>% 
  dplyr::mutate_if(is.character, as.numeric) %>% 
  dplyr::mutate_if(is.numeric, function(x){ifelse(is.na(x), 0, x)}) -> obitos_cor  

pop_total_regioes %>% 
  dplyr::rename(ano = 1, 
                pregiao_centro_oeste = 2, 
                pregiao_norte = 3, 
                pregiao_nordeste = 4,
                pregiao_sul = 5,
                pregiao_sudeste = 6) %>% 
  dplyr::mutate_if(is.character, as.numeric) -> pop_total_regioes

renda_per_capita %>% 
  dplyr::rename(ano = 1, 
                regiao_centro_oeste = 2, 
                regiao_norte = 3, 
                regiao_nordeste = 4,
                regiao_sul = 5,
                regiao_sudeste = 6) %>% 
  dplyr::mutate_if(is.character, as.numeric) -> renda_per_capita


pop_total_regioes <- pop_total_regioes %>% rename(ano_obito = ano)# Alteramos o nome de uma coluna da base
fujo<- full_join(obitos_regioes,pop_total_regioes, by = "ano_obito")# Juntamos as bases de interesse
op <- fujo %>% mutate(Norte = regiao_norte/(pregiao_norte/100000), 
                      Sul = regiao_sul/(pregiao_sul/100000),
                      Centro_Oeste = regiao_centro_oeste/(pregiao_centro_oeste/100000),
                      Nordeste = regiao_nordeste/(pregiao_nordeste/100000),
                      Sudeste = regiao_sudeste/(pregiao_sudeste/100000))#montamos as mortes relativas à população
op <-  op[1:18,]
op <- op %>% select(ano_obito,Norte, Sul, Sudeste, Centro_Oeste, Nordeste)# Aqui filtramos a base de dados

# Gráfico relacionando óbitos com etnia ----------------------------------------------------------------

obitos_cor %>% 
  dplyr::select(c(2:5)) -> obitos_cor_t # Selecionando apenas as informações importantes para o gráfico

obitos_cor_t <- colSums(obitos_cor_t) # Somando as colunas para obter os totais

obitos_cor_total <- data.frame(obitos_cor_t) # Criando um dataframe novo com os totais para fazer o gráfico
# O dataframe criado não possui o formato desejado, então será criado um novo dataframe de uma maneira que será útil
x <- data.frame('etnia' = c('branca', 'preta', 'parda', 'indigena'), 'obitos_t' = c(29, 16, 59, 5))

# Criando o gráfico de comparação de óbitos por etnia
ggplot(data = x) +
  geom_col(aes(x = etnia, y = obitos_t, fill = obitos_t),
           color = "black") +
  geom_text(aes(x = etnia, y = obitos_t, label = obitos_t),
            position = position_stack(vjust = 0.5), color = "white") +
  labs(x = "Etnia",
       y = "Obitos Totais",
       fill = NULL) + 
  scale_fill_viridis_c(option = "turbo")+
  theme_light()


# Gráficos de análise temporal de evolução de renda mortalidade-------------------------------------------------------------------------

# Para analisar se a evolução na renda per capita teve algum impacto sobre a 
# quantidade de óbitos ao longo dos anos, usamos a grid.arrange() para fazer a
# plotagem desses dois gráficos lado a lado, para cada uma das 5 regiões do Brasil

grid.arrange(ggplot(data = obitos_regioes[1:18,]) + # Limitamos a análise de óbitos
               # por região até o ano de 2014 (coluna 18), pois os dados sobre renda per capita só
               # estavam disponíveis até este ano. 
               geom_point(aes(x= ano_obito, y= regiao_norte)) +
               geom_smooth(aes(x= ano_obito, y = regiao_norte), level = 0.15) +
               labs(x = "Ano do óbito",
                    y = "Quantidade de mortes",
                    title = "Mortes maternas durante o parto",
                    subtitle = "Região Norte") +
               theme_bw(), 
             ggplot(data =  renda_per_capita) +
               geom_line(aes(x = ano, y = regiao_norte)) +
               labs(x = "Ano",
                    y = "Renda per capita",
                    title = "Renda per capita média",
                    subtitle = "Região Norte") +
               theme_bw(), 
             ncol=2)

grid.arrange(ggplot(data = obitos_regioes[1:18,]) +
               geom_point(aes(x= ano_obito, y = regiao_nordeste)) +
               geom_smooth(aes(x= ano_obito, y = regiao_nordeste), level = 0.15) +
               labs(x = "Ano do óbito",
                    y = "Quantidade de mortes",
                    title = "Mortes maternas durante o parto",
                    subtitle = "Região Nordeste") +
               theme_bw(), 
             ggplot(data =  renda_per_capita) +
               geom_line(aes(x = ano, y = regiao_nordeste)) +
               labs(x = "Ano",
                    y = "Renda per capita",
                    title = "Renda per capita média",
                    subtitle = "Região Nordeste") +
               theme_bw(), 
             ncol=2)

grid.arrange(ggplot(data = obitos_regioes[1:18,]) +
               geom_point(aes(x= ano_obito, y = regiao_sudeste)) +
               geom_smooth(aes(x= ano_obito, y = regiao_sudeste), level = 0.15) +
               labs(x = "Ano do óbito",
                    y = "Quantidade de mortes",
                    title = "Mortes maternas durante o parto",
                    subtitle = "Região Sudeste") +
               theme_bw(), 
             ggplot(data =  renda_per_capita) +
               geom_line(aes(x = ano, y = regiao_sudeste)) +
               labs(x = "Ano",
                    y = "Renda per capita",
                    title = "Renda per capita média",
                    subtitle = "Região Sudeste") +
               theme_bw(), 
             ncol=2)

grid.arrange(ggplot(data = obitos_regioes[1:18,]) +
               geom_point(aes(x= ano_obito, y = regiao_sul)) +
               geom_smooth(aes(x= ano_obito, y = regiao_sul), level = 0.15) +
               labs(x = "Ano do óbito",
                    y = "Quantidade de mortes",
                    title = "Mortes maternas durante o parto",
                    subtitle = "Região Sul") +
               theme_bw(), 
             ggplot(data =  renda_per_capita) +
               geom_line(aes(x = ano, y = regiao_sul)) + 
               labs(x = "Ano",
                    y = "Renda per capita",
                    title = "Renda per capita média",
                    subtitle = "Região Sul") +
               theme_bw(), 
             ncol=2)

grid.arrange(ggplot(data = obitos_regioes[1:18,]) +
               geom_point(aes(x= ano_obito, y = regiao_centro_oeste)) +
               geom_smooth(aes(x= ano_obito, y = regiao_centro_oeste), level = 0.15) +
               labs(x = "Ano do óbito",
                    y = "Quantidade de mortes",
                    title = "Mortes maternas durante o parto",
                    subtitle = "Região Centro Oeste") +
               theme_bw(), 
             ggplot(data =  renda_per_capita) +
               geom_line(aes(x = ano, y = regiao_centro_oeste)) + 
               labs(x = "Ano",
                    y = "Renda per capita",
                    title = "Renda per capita média",
                    subtitle = "Região Centro Oeste") +
               theme_bw(), 
             ncol=2)


# Grafico comparando óbitos entre as regiões-------------------------------------------------------------------------------

ggplot(data = op) + 
  geom_smooth(aes(x = ano_obito, y = Norte, color = 'Norte'), level = 0) +
  geom_smooth(aes(x = ano_obito, y = Sul, color = "Sul"), level = 0 ) + 
  geom_smooth(aes(x = ano_obito, y = Nordeste, color = "Nordeste"), level = 0 ) +
  geom_smooth(aes(x = ano_obito, y = Sudeste, color = "Sudeste"), level = 0) +
  geom_smooth(aes(x = ano_obito, y = Centro_Oeste, color = "Centro Oeste"), level = 0 ) + 
  scale_color_viridis_d(option = "turbo") +
  labs(x ="Ano do Óbito",
       y="Mortes Relativa à População",
       color= "Regiões",
       title = "Comparação de Óbitos por Região",
       caption = "Faixa Etária:10-14" )+
  theme_bw()
# Aqui montamos um gráfico comparativo entre as regiões
